const validar = document.getElementById("validar");


function datavalidar() {
    var data = document.getElementById("data");


    var dia = parseInt(data.value[0]+data.value[1]);
    var mes = parseInt(data.value[3]+data.value[4]);
    var ano = parseInt(data.value[6]+data.value[7]+data.value[8]+data.value[9]);

    // validar dias
    if (dia <1 || dia >31) {
        alert("Dia Inválido");
    }

    // validar meses
    if (mes<1 || mes >12) {
        alert("Mês Inválido")
    }

    // Só aceitar anos a partir de 1900
    if (ano<1900) {
        alert("Ano deve ser a partir de 1900");
    }

    // não aceitar 31 nos meses abaixo
    if (dia==31 && (mes==2 || mes==4 || mes==6 || mes==9 || mes==11)) {
        alert("Dia 31 invalído para o mês informado");
    }

    // não aceitar dia 30 em fevereiro
    if (dia==30 && mes==2) {
        alert("Dia 30 é inválido para fevereiro");
    }

    // encontrar ano bissexto
    var fator1 = ano % 4;
    var fator2 = ano % 100;
    var fator3 = ano % 400;
    var bissexto = 0;
    if (fator1 == 0 && fator2 != 0  || fator3 == 0) {
        bissexto=1;
    }

    // verificar 29/02 em ano bissexto
    if (dia==29 && mes == 2 && bissexto ==0) {
        alert("dia 29/fev Inválido. Não é ano bissexto");
    }




}

validar.addEventListener("click",datavalidar);